using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using LambdaService;
using LambdaService.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using Newtonsoft.Json;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace AWSLambda3;

public class MediaListFunction
{

    /// <summary>
    /// A simple function that takes a string and does a ToUpper
    /// </summary>
    /// <param name="input">The event for the Lambda function handler to process.</param>
    /// <param name="context">The ILambdaContext that provides methods for logging and describing the Lambda environment.</param>
    /// <returns></returns>
    //public async Task<APIGatewayProxyResponse> GetMediaFiles(string input, ILambdaContext context)
    //{
    //    return input.ToUpper();
    //}
    private readonly ICommonService? CommonService;
    private static ServiceCollection? serviceCollection;
    private readonly IRiskTechMediaService _rtMediaService;
    public MediaListFunction()
    {
        if (serviceCollection == null)
        {
            serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ICommonService, CommonServices>();
            serviceCollection.AddScoped<IRiskTechMediaService, RiskTechMediaService>();
            
        }
        var serviceProvider = serviceCollection.BuildServiceProvider();
        CommonService = serviceProvider.GetService<ICommonService>();
    }
    public async Task<APIGatewayProxyResponse> GetMediaFiles(APIGatewayProxyRequest request)
    {
        var response = new APIGatewayProxyResponse()
        {
            Headers = CommonService.GetResponseHeaders()
        };
        var result = await _rtMediaService.GetMediaListAsync(request.Body);
        response.StatusCode = result.StatusCode;
        response.Body = JsonConvert.SerializeObject(result.Body);
        return response;
    }
}
