﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    
        [Serializable]
        public class MediaListResponseModel
        {
            public IList<Claim> ClaimDetails { get; set; }

        }

        [Serializable]
        public class Claim
        {
            public string EventNumber { get; set; }

            public string ClaimNumber { get; set; }

            public IList<MediaInfo> MediaList { get; set; }

            public int MediaCount { get; set; }
        }

        [Serializable]
        public class MediaInfo
        {
            public string DocumentId { get; set; }

            public bool IsDownloadable { get; set; }

            public bool IsStreamable { get; set; }

            public string DownloadUrl { get; set; }

            public string StreamUrl { get; set; }

            public string UploadedFilename { get; set; }

            public string DocumentName { get; set; }

            public string Category { get; set; }

            public long FileSize { get; set; }

            public string FileType { get; set; }

            public DateTime UploadTimestamp { get; set; }

        }
    }

