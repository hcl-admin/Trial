﻿namespace Core
{
    public class BaseResponse
    {
        public int StatusCode { get; set; }
        public object Body { get; set; }

    }
}
