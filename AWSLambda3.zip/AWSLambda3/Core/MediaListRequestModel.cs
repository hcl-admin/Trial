﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class MediaListRequestModel
    {
        /// <summary>
        /// Claim Number
        /// </summary>
        public string ClaimNumber { get; set; }

        /// <summary>
        /// Event Number
        /// </summary>
        public string EventNumber { get; set; }

        /// <summary>
        /// Indicates whether to send all files or only the matching ones.
        /// </summary>
        public bool All { get; set; }

        /// <summary>
        /// Tracking ID
        /// </summary>
        public string TrackingId { get; set; }
    }
}
