﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public static class ResponseMessages
    {
        public static readonly string ValidationError = "A validation error occurred.";
        public static readonly string UserAuthError = "User doesn't have the right permission to access categories. Please contact the System Administrator.";
        public static readonly string UserRecordNotFound = "User record not found. Please contact the System Administrator.";
        public static readonly string CategoryRecordsNotFound = "Category record not found. Please contact the System Administrator.";
        public static readonly string DocumentDownloadRecordsNotFound = "Documents record not found for download.";
        public static readonly string CategoryParamRecordsNotFound = "Requested category parameter records not found. Please contact the System Administrator.";
        public static readonly string SearchMetaDataRecordsNotFound = "Search results record not found.";
        public static readonly string SearchOperatorsRecordsNotFound = "Search operator's record not found. Please contact the System Administrator";
        public static readonly string InternalServerError = "A Server Error Occurred. Please Contact the System Administartor.";
        public static readonly string UpdateUploadError = "Internal server error for update upload success.";
        public static readonly string UploadDocumentError = "Internal server error for upload document.";
        public static readonly string UserAuthAdminError = "User doesn't have the right permission to upload a document. Please contact the System Administrator.";
        public static readonly string UserCodeError = "User Code is required.";
        public static readonly string CategoryCodeError = "Category Code is required.";
        public static readonly string RequestIdError = "RequestId is required.";
        public static readonly string UserIPError = "UserIP is required.";
        public static readonly string ItemIdsError = "ItemIds are required.";
        public static readonly string FileNameError = "FileName is required.";
        public static readonly string UploadFieldsError = "UploadFields are required.";
        public static readonly string ITEM_IDError = "ITEM_ID is required.";
        public static readonly string ConditionError = "AND or OR Condition is required.";
        public static readonly string SearchFieldsError = "Search Fields are required.";
        public static readonly string DocumentIdsError = "DocumentIds are required.";
        public static readonly string FileDownlodDetailsNotFound = "File download details record not found.";
        public static readonly string RequestBodyEmpty = "E001:Invalid request format";
        public static readonly string WarmUpResponseBody = "Warmed up!";
        public static readonly string ResponseSuccess = "Success";
        public static readonly string ClaimAndEventNumberEmpty = "E003:Both Claim Number and Event Number cannot be empty.";
        public static readonly string UnableToRetrieveAccessToken = "Unable to retrieve access token.";
        public static readonly string TrackingIdEmpty = "E004:Tracking ID cannot be empty.";
        public static readonly string InvalidMediaListRequestFormat = "E002:Invalid request format.";
        public static readonly string EventNumberEmpty = "E025: EventNumber cannot be empty.";
        public static readonly string MediaIdEmpty = "E026: MediaId cannot be empty.";
        public static readonly string MediaIdNonNumeric = "E027: Invalid MediaId format.";
        public static readonly string TrackingIdRequired = "E028: Tracking ID cannot be empty";
        public static readonly string TrackingIdInvalid = "E029: Invalid Parameters!";
        public static readonly string MediaIdInvalid = "E030: Invalid Parameters!";
        public static readonly string EventNumberInvalid = "E031: Invalid Parameters!";

    }
}
