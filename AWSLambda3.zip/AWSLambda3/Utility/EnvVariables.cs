﻿namespace Utility
{
    public static class EnvVariables
    {
        
        public static string Region = "us-east-1";
       
        public static string AllowOrigin = "*";//In Mb
         public static string CloudFrontURL = "https://cloudFrontURL.cloudfront.net/";
        
    }
}