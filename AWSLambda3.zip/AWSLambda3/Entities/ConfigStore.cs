﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    [DynamoDBTable("ConfigStore")]
    public  class ConfigStore<T>
    {
        [DynamoDBHashKey("configName")]
        public required string ConfigName { get; set; }

        [DynamoDBRangeKey("isActive")]
        public int IsActive { get; set; }

        [DynamoDBProperty("configValues")]
        public required T Config { get; set; }
    }
}
