﻿using Amazon.DynamoDBv2.DataModel;

namespace Entities
{
    [DynamoDBTable("MediaStore")]
    public class MediaStore
    {
        
        
            [DynamoDBHashKey("bdpDocumentID")]
            public long DocumentId { get; set; }

            [DynamoDBProperty("bdpDocumentName")]
            public  string DocumentName { get; set; }

            [DynamoDBProperty("bitrate")]
            public int BitRate { get; set; }

            [DynamoDBProperty("categories")]
            public  string Category { get; set; }

            [DynamoDBGlobalSecondaryIndexHashKey("MediaStore-event")]
            [DynamoDBProperty("eventNumber")]
            public  string EventNumber { get; set; }


            [DynamoDBGlobalSecondaryIndexHashKey("MediaStore-claim")]
            [DynamoDBProperty("claimNumber")]
            public required string ClaimNumber { get; set; }

        [DynamoDBProperty("isActive")]
        [DynamoDBGlobalSecondaryIndexRangeKey("MediaStore-event")]
        public bool IsActive { get; set; }

        [DynamoDBProperty("isDownloadable")]
        public int IsDownloadable { get; set; }

        [DynamoDBProperty("isStreamable")]
        public int IsStreamable { get; set; }


        [DynamoDBProperty("uploadedFilename")]
        public string UploadedFileName { get; set; }

        [DynamoDBProperty("fileTypeFormat")]
        public string FileTypeFormat { get; set; }

        [DynamoDBProperty("uploadTimestamp")]
        public long UploadTimestamp { get; set; }

        [DynamoDBProperty("fileSize")]
        public long FileSize { get; set; }

    }

    }
    
