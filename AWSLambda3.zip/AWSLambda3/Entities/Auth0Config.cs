﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Auth0Config
    {
        [DynamoDBProperty("audience")]
        public required string Audience { get; set; }

        [DynamoDBProperty("tokenEndPoint")]
        public required string TokenEndPoint { get; set; }

        [DynamoDBProperty("clientId")]
        public required string ClientId { get; set; }

        [DynamoDBProperty("clientSecret")]
        public required string ClientSecret { get; set; }
    }
}
