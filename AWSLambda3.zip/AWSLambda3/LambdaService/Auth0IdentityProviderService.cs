﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Data;

namespace LambdaService
{
    public class Auth0IdentityProviderService
    {
        private const string HEADER_FORM_URL_ENCODED_VALUE = "application/x-www-form-urlencoded";
        private const string BDP_UNIQUE_ID = "bdp_unique_id";
        private const string AUTH0_GRANT_TYPE = "grant_type";
        private const string AUTH0_CLIENT_ID = "client_id";
        private const string AUTH0_CLIENT_SECRET = "client_secret";
        private const string AUTH0_AUDIENCE = "audience";
        private const string AUTH0_GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials";
        private const string AUTH0_TOKEN_TYPE_ACCESS_TOKEN = "access_token";
        private const string AUTH0_TOKEN_EXPIRESIN = "expires_in";

        private readonly IConfigStoreRepository _configStoreRepository;

        public Auth0IdentityProviderService(IConfigStoreRepository configstorerepository)
        {
            _configStoreRepository = configstorerepository;
        }
        public async Task<(string token, string expireAt)> GenerateTokenAsync(string uniqueId)
        {
            return await RetrieveAccessTokenAsync(uniqueId);
        }

        private async Task<(string token, string expireAt)> RetrieveAccessTokenAsync(string uniqueId)
        {
            // Validation of Token
            return (token: string.Empty, expireAt: string.Empty);
        }
    }
}
