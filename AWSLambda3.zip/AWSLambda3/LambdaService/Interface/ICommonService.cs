﻿using Amazon;


namespace LambdaService.Interface
{
    public  interface ICommonService
    {
        Dictionary<string, string> GetResponseHeaders();
        bool CheckDateFormat(string input);
        string ConvertStringToDate(string input);
        string ConvertDateToString(string input);
        RegionEndpoint GetRegion();
    }
}
