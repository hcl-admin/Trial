﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;

namespace LambdaService.Interface
{
    public interface IRiskTechMediaService
    {
        Task<BaseResponse> GetMediaListAsync(string mediaListRequest);
    }
}
