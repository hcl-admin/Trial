﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaService.Interface
{
    public  interface IIdentityProviderService
    {
        Task<(string token, string expireAt)> GenerateTokenAsync(string uniqueId);
    }
}
