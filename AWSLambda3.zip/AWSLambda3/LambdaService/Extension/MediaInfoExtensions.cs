﻿using Core;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaService.Extension
{
    public static class MediaInfoExtensions
    {
        public static MediaInfo FromMediaStore(this MediaInfo mediaInfo, MediaStore mediaStore)
        {
            if (mediaStore == null)
            {
                return default;
            }

            mediaInfo.DocumentId = mediaStore.DocumentId.ToString();
            mediaInfo.IsDownloadable = mediaStore.IsDownloadable == 1;
            mediaInfo.IsStreamable = mediaStore.IsStreamable == 1;
            mediaInfo.UploadedFilename = mediaStore.UploadedFileName;
            mediaInfo.DocumentName = mediaStore.DocumentName;
            mediaInfo.FileType = mediaStore.FileTypeFormat;
            mediaInfo.UploadTimestamp = DateTimeOffset.FromUnixTimeSeconds(mediaStore.UploadTimestamp).UtcDateTime;
            mediaInfo.FileSize = mediaStore.FileSize;
            mediaInfo.Category = mediaStore.Category;

            return mediaInfo;
        }
    }
}
