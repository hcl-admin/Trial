﻿using Core;
using LambdaService.Interface;
using LambdaService.Extension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;
using Entities;
using Newtonsoft.Json;
using Utility;
using System.ComponentModel.DataAnnotations;
using System.Net;


namespace LambdaService
{
    public class RiskTechMediaService : IRiskTechMediaService
    {
        private readonly string CLOUDFRONT_URL = EnvVariables.CloudFrontURL;
        private readonly IMediaStoreRepository _mediaStoreRepository;
        private readonly IIdentityProviderService _identityProviderService;
        

        public RiskTechMediaService(IMediaStoreRepository mediaStoreRepository,
            IIdentityProviderService identityProviderService)
        {
            _mediaStoreRepository = mediaStoreRepository ?? throw new ArgumentNullException(nameof(mediaStoreRepository));
            _identityProviderService = identityProviderService ?? throw new ArgumentNullException(nameof(identityProviderService));
        }
        async Task<BaseResponse> IRiskTechMediaService.GetMediaListAsync(string mediaListRequest)
        {
            var validationResult = ValidateRequest(mediaListRequest);

            if (validationResult.StatusCode != (int)HttpStatusCode.OK)
            {
                return validationResult;
            }
            var requestModel = JsonConvert.DeserializeObject<MediaListRequestModel>(mediaListRequest);

            var mediaFiles = await  _mediaStoreRepository.GetMediaListByClaimNumberAsync(requestModel.ClaimNumber);

            var claimDetailsList = BuildClaimDetailsListAsync(mediaFiles, requestModel);

            var responseObject = BuildMedialListResponseModel(claimDetailsList);

            validationResult.Body = responseObject;
            return validationResult;

        }

        private BaseResponse ValidateRequest(string mediaListRequest)
        {
            BaseResponse response = new BaseResponse()
            {
                StatusCode = (int)HttpStatusCode.OK
            };

            if (string.IsNullOrEmpty(mediaListRequest))
            {
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Body = ResponseMessages.RequestBodyEmpty;
                return response;
            }

            MediaListRequestModel requestModel = null;
            try
            {
                requestModel = JsonConvert.DeserializeObject<MediaListRequestModel>(mediaListRequest);
            }
            catch { }

            if (requestModel == null)
            {
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Body = ResponseMessages.InvalidMediaListRequestFormat;
                return response;
            }

            if (string.IsNullOrEmpty(requestModel.ClaimNumber) && string.IsNullOrEmpty(requestModel.EventNumber))
            {
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Body = ResponseMessages.ClaimAndEventNumberEmpty;
                return response;
            }

            if (string.IsNullOrEmpty(requestModel.TrackingId))
            {
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Body = ResponseMessages.TrackingIdEmpty;
                return response;
            }

            return response;
        }



        private static MediaListResponseModel BuildMedialListResponseModel(IList<Claim> claims)
        {
            return new MediaListResponseModel
            {
                ClaimDetails = claims
            };
        }
        private IList<MediaStore> FilterMediaList(string eventNumber, string claim, bool all, IList<MediaStore> mediafiles)
        {
            IList<MediaStore> filteredList;
            if (!string.IsNullOrEmpty(eventNumber) && !string.IsNullOrEmpty(claim) && all)
            {
                filteredList = mediafiles.Where(x => x.EventNumber.Equals(eventNumber) &&
                                               (x.ClaimNumber.Trim().Equals(claim) || string.IsNullOrEmpty(x.ClaimNumber.Trim())))
                                         .Select(x => x)
                                         .ToList();
            }
            else if (!string.IsNullOrEmpty(eventNumber) && !string.IsNullOrEmpty(claim) && !all)
            {
                filteredList = mediafiles.Where(x => x.EventNumber.Equals(eventNumber) && x.ClaimNumber.Trim().Equals(claim))
                                         .Select(x => x)
                                         .ToList();
            }
            else if (!string.IsNullOrEmpty(eventNumber) && string.IsNullOrEmpty(claim) && all)
            {
                filteredList = mediafiles.Where(x => x.EventNumber.Equals(eventNumber))
                                         .Select(x => x)
                                         .ToList();
            }
            else if (!string.IsNullOrEmpty(eventNumber) && string.IsNullOrEmpty(claim) && !all)
            {
                filteredList = mediafiles.Where(x => x.EventNumber.Equals(eventNumber) && string.IsNullOrEmpty(x.ClaimNumber.Trim()))
                                         .Select(x => x)
                                         .ToList();
            }
            else if (string.IsNullOrEmpty(eventNumber) && !string.IsNullOrEmpty(claim))
            {
                filteredList = mediafiles.Where(x => x.ClaimNumber.Trim().Equals(claim))
                                         .Select(x => x)
                                         .ToList();
            }
            else
            {
                filteredList = new List<MediaStore>();
            }

            return filteredList;
        }
        private List<Claim> BuildClaimDetailsListAsync(
           List<MediaStore> mediaFiles, MediaListRequestModel request)//one last argument need tobe reviewed
        {
            var filteredMediaFiles = FilterMediaList(request.EventNumber, request.ClaimNumber, request.All, mediaFiles);

            var claimList = filteredMediaFiles
                            .Where(m => m.IsActive)
                            .GroupBy(groupingKey => new
                            {
                                EventNumber = groupingKey.EventNumber.Trim(),
                                ClaimNumber = groupingKey.ClaimNumber.Trim()
                            })
                            .Select(x =>
                            {
                                var claim = new Claim
                                {
                                    ClaimNumber = x.Key.ClaimNumber.Trim(),
                                    EventNumber = x.Key.EventNumber,
                                    MediaList = x.Select(m =>
                                    {
                                        var mediaInfo = (new MediaInfo()).FromMediaStore(m);
                                        mediaInfo.StreamUrl = mediaInfo.IsStreamable ? BuildStreamUrl(m.DocumentId) : string.Empty;
                                        mediaInfo.DownloadUrl = BuildDownloadUrl(m.DocumentId);
                                        return mediaInfo;
                                    }).ToList(),
                                };
                                claim.MediaCount = claim.MediaList.Count();

                                return claim;
                            });

            var resultClaimList = claimList.ToList();

            return resultClaimList;
        }
        private string BuildDownloadUrl(long id)
        {

            return $"{CLOUDFRONT_URL}/download/{id}";
        }

        private string BuildStreamUrl(long id)
        {
            return $"{CLOUDFRONT_URL}/stream/{id}";
        }

    }
}
