﻿using LambdaService.Interface;
using Microsoft.VisualBasic;
using System.Globalization;
using Utility;
using Amazon;

namespace LambdaService
{
    public class CommonServices:ICommonService
    {
        private readonly string AllowOrigin;
        private readonly string Region;
        public CommonServices()
        {
            AllowOrigin = EnvVariables.AllowOrigin;
            Region = EnvVariables.Region;
        }

        public Dictionary<string, string> GetResponseHeaders()
        {
            var keyValues = new Dictionary<string, string>()
            {
                { "Access-Control-Allow-Origin", AllowOrigin },
                { "Access-Control-Allow-Headers", "Content-Type,Authorization" },
                { "Access-Control-Allow-Methods", "OPTIONS,POST" },
                { "Content-Type", "application/json" }
            };

            return keyValues;
        }
        public bool CheckDateFormat(string input)
        {
            bool output = false;
            string[] arrayStr = input.Split('/');
            if (Convert.ToInt32(arrayStr[0]) <= 12)
            {
                output = true;
            }
            if (output == true && Convert.ToInt32(arrayStr[1]) <= 31)
            {
                output = true;
            }
            else
            {
                output = false;
            }
            if (output == true && arrayStr[2].Length == 4)
            {
                output = true;
            }
            else
            {
                output = false;
            }
            return output;
        }
        public string ConvertStringToDate(string input)
        {
            return " STR_TO_DATE('" + input + "', '" + Constants.vbShortDate + "') ";
        }
        public string ConvertDateToString(string input)
        {
            return input;
        }
        public RegionEndpoint GetRegion()
        {
            if (!string.IsNullOrEmpty(Region))
            {
                return RegionEndpoint.GetBySystemName(Region);
            }
            else
            {
                return RegionEndpoint.GetBySystemName(RegionInfo.CurrentRegion.Name);
            }

        }

    }
}
