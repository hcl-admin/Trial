﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace Data
{
    public class MediaStoreRepository : IMediaStoreRepository
    {
        private const string MEDIA_STORE_CLAIM_NUMBER_INDEX_NAME = "MediaStore-claim";
        
        private readonly IAmazonDynamoDB _dynamoDBClient;
        private readonly IDynamoDBContext _dynamoDbContext;

        public MediaStoreRepository(IAmazonDynamoDB dynamoDBClient, IDynamoDBContext dynamoDbContext)
        {
            _dynamoDBClient = dynamoDBClient ?? throw new ArgumentNullException(nameof(dynamoDBClient));
            _dynamoDbContext = dynamoDbContext ?? throw new ArgumentNullException(nameof(dynamoDbContext));
        }
        public async Task<List<MediaStore>> GetMediaListByClaimNumberAsync(string claimNumber)
        {
            var operationConfig = new DynamoDBOperationConfig
            {
                IndexName = MEDIA_STORE_CLAIM_NUMBER_INDEX_NAME
            };
            var result = await _dynamoDbContext.QueryAsync<MediaStore>(claimNumber, operationConfig).GetRemainingAsync();
            return result;
        }

    }
}
