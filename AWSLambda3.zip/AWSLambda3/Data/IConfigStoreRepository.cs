﻿using Entities;
namespace Data
{
    public interface IConfigStoreRepository
    {
        Task<ConfigStore<Auth0Config>> GetAuth0Configuration();

    }
}
