﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public  class ConfigStoreRepository: IConfigStoreRepository
    {
        private const string AUTH0_CONFIG_NAME = "Auth0Credential";

        private const string CONFIG_STORE_IS_ACTIVE = "IsActive";

        private readonly IAmazonDynamoDB _dynamoDBClient;
        private readonly IDynamoDBContext _dynamoDbContext;

        public ConfigStoreRepository(IAmazonDynamoDB dynamoDBClient, IDynamoDBContext dynamoDbContext)
        {
            _dynamoDBClient = dynamoDBClient ?? throw new ArgumentNullException(nameof(dynamoDBClient));
            _dynamoDbContext = dynamoDbContext ?? throw new ArgumentNullException(nameof(dynamoDbContext));

        }

        public async Task<ConfigStore<Auth0Config>> GetAuth0Configuration()
        {
            var operationConfig = new DynamoDBOperationConfig
            {
                QueryFilter = new List<ScanCondition>
                {
                    new ScanCondition(CONFIG_STORE_IS_ACTIVE, ScanOperator.Equal, 1)
                }
            };
            var result = await _dynamoDbContext.QueryAsync<ConfigStore<Auth0Config>>(AUTH0_CONFIG_NAME, operationConfig).GetRemainingAsync();
            return result.FirstOrDefault();
        }

    }
}
